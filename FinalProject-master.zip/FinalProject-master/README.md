# FinalProject
accepting all Gonorrhea patients 
